/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bellos.courseapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This class encapsulates information about a particular course. Which includes
 * it's Course ID, Course Name, Course Code, Instructor and enrolled students.
 * 
 */
class Course {
    private String courseId;
    private String courseName;
    private String courseCode;
    private Instructor instructor;
    private final List<Student> roster;

    public Course(String courseId, String courseName, String courseCode, Instructor instructor) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.instructor = instructor;
        this.roster = new ArrayList<>();
    }
    
    public Course(){
        this.roster = new ArrayList<>();
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public Instructor getInstructor() {
        return instructor;
    }

    public void setInstructor(Instructor instructor) {
        this.instructor = instructor;
    }

    public void addStudent(Student student) {
        roster.add(student);
        Collections.sort(roster);
    }

    public void removeStudent(String personId) {
        roster.removeIf(student -> student.getPersonId().equals(personId));
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Course ID: ").append(courseId).append("\n");
        sb.append("Course Name: ").append(courseName).append("\n");
        sb.append("Course Code: ").append(courseCode).append("\n\n");
        sb.append("Instructor\n---------------------------------\n");
        sb.append(instructor.toString()).append("\n\n");
        sb.append("Student Roster\n---------------------------------\n");
        for (Student student : roster) {
            sb.append(student.toString()).append("\n");
        }
        return sb.toString();
    }
}
