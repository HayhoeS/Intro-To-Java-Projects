/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bellos.interestapp;
import java.util.Scanner;
/**
 *
 * @author Sasha Hayhoe
 * CITP 190 : Interest Calculator
 * This program is designed to calculate the monthly compound interest on a user's
 * savings account.
 */
public class BellosInterestApp {

    public static void main(String[] args) {
        //variables
        double principal;
        double apr;
        int years;
        double monthlyRate;
        double annualRate;
        double termRate;
        double accrued;
        char runAgain = 'y';
        Scanner userInput = new Scanner(System.in);  //variable to get user input
        String invalid = "\nInvalid input. Please enter a valid number";
        
        System.out.println("This program is designed to calculate monthly"
                    + "monthly compound interest on a savings account.");
        
        //loop to run calculation again
        while (runAgain == 'y' || runAgain == 'Y')
        {
            //get user input on principle
            while(true)
            {
                System.out.println("Enter Principal amount: $");
                if (userInput.hasNextDouble()) //validate user input
                { 
                    principal = userInput.nextDouble(); 
                    break;
                }
                else
                {
                    System.out.println(invalid);
                    userInput.next();
                }
            }
                     
            //get user input on apr
            while (true)
            {
                System.out.println("Enter APR amount: ");
                //validate user input
                if (userInput.hasNextDouble())
                {
                    apr = userInput.nextDouble();
                    break;
                }
                else{
                    System.out.println(invalid);
                    userInput.next();
                }    //(apr = Double.parseDouble(userInput.nextLine());
            }
            
            

            //get user input on number of years
            while (true){
                System.out.println("Enter Term [in years]: ");
                
                if (userInput.hasNextInt()){
                    years = userInput.nextInt();
                    break;                
                }
                else{
                    System.out.println(invalid);
                    userInput.next();
                }
            }                      

            //run calculations
            monthlyRate = 1 + (apr/1200);
            annualRate = Math.pow(monthlyRate,12);
            termRate = Math.pow(annualRate,years);
            accrued = principal * termRate;

            //display total and run program again prompt
            System.out.println("Accrued Amount: " + accrued);
            System.out.println("Would you like to run another calculation? Y or y");
            userInput.nextLine();
            runAgain = userInput.nextLine().charAt(0);
        }
    }
}
