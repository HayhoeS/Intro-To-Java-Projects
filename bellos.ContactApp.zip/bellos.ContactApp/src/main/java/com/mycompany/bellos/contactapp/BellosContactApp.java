/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bellos.contactapp;
import java.util.Scanner;

/*
 * @author Sasha Hayhoe
 * CITP 190 : Contact App
 * This progam creates a Contact Book in which a user can add, update or remove contacts
 * into an array collection.
 */

public class BellosContactApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ContactBook contactBook = new ContactBook(0); //inital capacity    
                       
        int choice;
        int index;
        String name;
        String address;
        String phone;
        String email;
        String input;
        
        System.out.println("Please select one of the following options for your contact book.\n");
                
        while(true){
            //prompt user menu selection            
            System.out.println(
                    "1. List all Contacts\n" + 
                    "2. Add a Contact\n" +
                    "3. Update a Contact\n" +
                    "4. Remove a Contact\n" +
                    "5. Exit\n");
            
            input = scanner.nextLine();
            
            if (input.equals("5")){
                break;
            }
            
            if(input.equals("1") || input.equals("2") ||input.equals("3") || input.equals("4")){
                //switch case
                switch(input){
                    case "1": //call the ContactBook toString method
                        if (contactBook.getEntriesLength() == 0) {
                            System.out.println("No Entries Found");
                            break; // Exit the switch statement
                        }
                        else{
                        System.out.println(contactBook.toString());
                        break;}
                        
                    case "2":                        
                        //call ContactInfo method and add as new contact.
                        Contact newContact = ContactInfo(scanner);
                        contactBook.add(newContact);
                        break; //break case 2
                        
                    case "3":                       
                        // Break the switch case if no entries found
                        if (contactBook.getEntriesLength() == 0) 
                        {
                            break;
                        }
                        System.out.println(contactBook); //print contact book

                        System.out.println("Enter index of contact to change. Or 'E' to exit");

                        while (true) 
                        {
                            input = scanner.nextLine();                            
                            index = Index(scanner, contactBook, input); //get index using Index to updateContact
                            
                            if (index == -1) {
                                break; //if user types "E" or "e" method returns -1 and breaks loop
                            }
                            else{
                                //call ContactInfo method and get string inputs
                                Contact updateContact = ContactInfo(scanner);

                                // Update the contact in the contactBook
                                contactBook.update(index, updateContact);
                            }                            
                            break; //exit while loop after updating contact
                        }
                        break; //break case 3
                    
                    case "4":
                        
                        System.out.println(contactBook);
                        System.out.println("Please enter index you wish to remove.");
                                                
                        while(true)
                        {
                            input = scanner.nextLine();
                            index = Index(scanner, contactBook, input);
                            if(index == -1){
                                break;
                            }else{
                                System.out.println("Are you sure you'd like to remove this entry? [y] or [n]");
                                String confirmation = scanner.nextLine();
                                if (confirmation.equalsIgnoreCase("y")) {
                                    contactBook.remove(index);
                                    break; // Exit the loop once removal is confirmed
                                } else if (confirmation.equalsIgnoreCase("n")) {
                                    System.out.println("Contact removal was cancelled..");
                                    break; // Exit the loop if removal is canceled
                                } else {
                                    System.out.println("Invalid input. Please enter [y] or [n]");
                                }
                            }
                          
                            /*// Assume indexToRemove is the index you want to remove
                            if (!input.matches("\\d+")) {
                                    System.out.println("Invalid Index");
                                    continue; // Continue to prompt for valid input
                                }

                            int indexToRemove = Integer.parseInt(input);
                            
                            if (indexToRemove < 0 || indexToRemove >= contactBook.getEntriesLength()) {
                                    System.out.println("Invalid index.");
                                    continue; // Continue to prompt for valid input
                                }*/
                            //index = Index(scanner, contactBook, input);                            
                        }
                    break; //break switch case 4
                }
            }            
        }
        
    }
    //method to return contact info to main method
    public static Contact ContactInfo(Scanner scanner){
        
        System.out.println("Enter a new name:");
        String name = scanner.nextLine();
        System.out.println("Enter a new address:");
        String address = scanner.nextLine();
        System.out.println("Enter a new phone number:");
        String phone = scanner.nextLine();
        System.out.println("Enter a new email address:");
        String email = scanner.nextLine();
        return new Contact(name, address, phone, email);
    }
    public static int Index(Scanner scanner, ContactBook contactBook, String input) {
    int indexToUpdate = -1;

        while (true) {
            if (input.equalsIgnoreCase("E")) {
                return -1; // Exit the method
            }

            if (!input.matches("\\d+")) {
                System.out.println("Invalid input. Please enter a valid integer index or 'E' to exit.");
            } else {
                indexToUpdate = Integer.parseInt(input);

                if (indexToUpdate < 0 || indexToUpdate >= contactBook.getEntriesLength()) {
                    System.out.println("Invalid index. Please enter a valid index or 'E' to exit.");
                } else {
                    break; // Exit the loop if input is valid
                }
            }

            input = scanner.nextLine(); // Prompt for new input
        }
        return indexToUpdate;
    }   
}
