/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bellos.contactapp;

/**
 *
 * @author Elieya
 * CITP 190
 * ContactBook : Creates array of Contact Entries and allows user to add, update
 * or remove entries from array.
 */
public class ContactBook {
    
    private Contact[] entries;
    
    public ContactBook(int size){
        this.entries = new Contact[size];               
    }
    
    public void add(Contact contact) {
        if (entries.length == 0) { // Handle initial empty array
            entries = new Contact[1]; // resize the array to equal 1
        } else if (entries.length == entries.length) { // Check if array is full
            Contact[] newEntries = new Contact[entries.length +1]; //resize the array to add one new empty entry
            
            //source array, starting index of source array, new destination array, starting index of new array
            System.arraycopy(entries, 0, newEntries, 0, entries.length); 
            entries = newEntries; //assign newEntries back to entries
        }
        entries[entries.length -1] = contact; // Add new contact to the end (last position)
        System.out.println("Contact added successfully!\n");
    }
    
    //added this method in as a way to validate the length of the array
    //used in user validation to validate if an index input is valid
    public int getEntriesLength(){
        return entries.length;
    }
    
    //update contact info given a valid index
    public void update(int index, Contact contact) {
            entries[index] = contact;
            System.out.println("Contact updated successfully.\n");

    }
    
    //remove contact from ContactBook array and update list so no missing or null array elements
    public void remove(int index) {
        //create new array
        Contact[] newEntries = new Contact[entries.length - 1];
        // Copy elements before the index
        System.arraycopy(entries, 0, newEntries, 0, index);
        // Copy elements after the index
        System.arraycopy(entries, index + 1, newEntries, index, entries.length - index - 1);
        entries = newEntries; //copy newEntries to entries array
        System.out.println("Contact removed successfully.\n");
        
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();

        result.append("Contact Book Entries:\n");
        
        //displays contents of entries array
        for (int i = 0; i < entries.length; i++) {            
            result.append(i).append("  ");
            result.append(entries[i].toString()).append("\n");           
        }
        return result.toString();
    }
}
