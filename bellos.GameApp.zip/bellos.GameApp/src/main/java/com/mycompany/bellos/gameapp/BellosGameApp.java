/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bellos.gameapp;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author Elieya
 */
public class BellosGameApp {

    public static void main(String[] args) {
        
        //variables
        char playAgain = 'y';
        int computerChoice;
        int playerChoice;
        int computerWinCount = 0;
        int playerWinCount = 0;
        String winner;
        Scanner input = new Scanner(System.in);
        Random r = new Random();
        
        System.out.println("This is a program to play Rock, Paper, Scissors against a computer!");
        
        //loop to prompt player to play again
        while (playAgain == 'y' || playAgain == 'Y')
        {
            //computer picks random number: 0, 1, 2
            computerChoice = r.nextInt(2)+1;
            
            //run methods
            playerChoice = GetPlayerDecision(input);                  
            winner = DetermineWinner(playerChoice, computerChoice);
            
            //if winner equals computer increase computerWinCount, else increase playerWinCount
            if ("computer".equals(winner)){
                computerWinCount++;                
            }
            else if("player".equals(winner)){
                playerWinCount++;
            }
            System.out.println("\nPlayer Wins: " + playerWinCount+
                    "\nComputer Wins: " + computerWinCount);
           
            //prompt user to play again
            System.out.println("\nWould you like to play again? Y or N");
            playAgain = input.nextLine().charAt(0);
        }                       
    }
    
    static int GetPlayerDecision(Scanner input){
        //variables needed in method
        char playerChoice;
        String playerChoiceDisplay;
        int playerChoiceNumber;
        
        System.out.println("\nChoose:\n[R] for Rock\n[S] for Scissors\n[P] for Paper\n");
        
        //loop to set playerChoice as int
        loop:
        while(true){
            playerChoice = input.nextLine().charAt(0);
                       
            switch(playerChoice){
                case 'R', 'r' -> {
                    playerChoiceDisplay = "\nYou chose Rock!";
                    playerChoiceNumber = 0;
                    break loop;
                }
                case 'S', 's' -> {
                    playerChoiceDisplay = "\nYou chose Scissors";
                    playerChoiceNumber = 1;
                    break loop;
                }
                case 'P', 'p' -> {
                    playerChoiceDisplay = "\nYou chose Paper";
                    playerChoiceNumber = 2;
                    break loop;
                }
                default -> System.out.println("Invalid Input: Try Again\n");                
            }           
        }
        System.out.println(playerChoiceDisplay);              
        return playerChoiceNumber;
    }
    
    static String DetermineWinner(int playerChoice, int computerChoice){
        String message = "";
        String winner = "";
        
        
        //if game tied, otherwise determine winner
        if (playerChoice == computerChoice){
            message = "Computer chose the same! Tie Game!";
        }
        else if (playerChoice == 0){ //if player chooses rock
            if (computerChoice == 1){ //if computer chooses scissors
                message = "Computer chose Scissors.\nPlayer wins!";
                winner = "player";
            }
            else{ //if computer chooses paper
                message = "Computer chose Paper. \nComputer wins!";
                winner = "computer";
            }
        }
        else if (playerChoice == 1){ //if player chooses scissors
            if (computerChoice == 0){ //if computer chooses rock
                message = "Computer chose Rock.\nComputer wins!";
                winner = "computer";
            }
            else{ //if computer chooses paper
                message = "Computer chose Paper. \nPlayer wins!";
                winner = "player";
            }
        }
        else if(playerChoice == 2){ //if player chooses paper
            if (computerChoice == 1){ //if computer chooses scissors
                message = "Computer chose Scissors.\nComputer Wins!";
                winner = "computer";
            }
            else{ //if computer chooses rock
                message = "Computer chose Rock.\nPlayer wins!";
                winner = "player";
            }           
        }
        
        //print winning message to user
        System.out.println(message);
        
        return winner;
        
    }
}
