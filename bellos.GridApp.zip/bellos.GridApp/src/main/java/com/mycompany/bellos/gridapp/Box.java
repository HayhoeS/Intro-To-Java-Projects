/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bellos.gridapp;

/**
 *
 * @author Elieya
 */
public class Box {
    //variables
    private static final int MIN_X = 0;
    private static final int MIN_Y = 0;

    private final int maxX;
    private final int maxY;

    private int x = MIN_X;
    private int y = MIN_Y;
    
    //constructor
    public Box(int maxX, int maxY) {
        this.maxX = maxX;
        this.maxY = maxY;
    }

    //
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    //push box in direction of user input
    public void Push(Vector vector) {
        int newX = x;
        int newY = y;

        switch (vector.GetDirection()) {
            case "R":
                newX += vector.GetMagnitude();
                break;
            case "U":
                newY -= vector.GetMagnitude();
                break;
            case "L":
                newX -= vector.GetMagnitude();
                break;
            case "D":
                newY += vector.GetMagnitude();
                break;
        }

        // Ensure newX and newY stay within bounds
        x = Math.max(Math.min(newX, maxX), MIN_X);
        y = Math.max(Math.min(newY, maxY), MIN_Y);
    }
}
