/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bellos.gridapp;
import java.util.Scanner;

/*
 * @author Sasha Hayhoe
 * CITP 190 : Box Grid
 * This program is used to simulate a box moving around in grid. The user inputs
 * which direction and how far they'd like the box to move in the grid.
 */
public class BellosGridApp {

    public static void main(String[] args) {
        //variables needed
        Scanner scanner = new Scanner(System.in);
        Grid grid = new Grid(10, 10);// Creating a grid with vertical and horizontal sizes of 10
        Box box; //box class variable
        Vector vector; //vector class variable
        int magnitude; //
        String input; //variable to loop user input
               
        grid.Draw(); //call the draw method on the grid class first
        
        //while user input is valid
        while (true) {                        
            System.out.print("Enter (U)p, (D)own, (L)eft, (R)ight, or (E)xit: "); //get user input
            input = scanner.nextLine().toUpperCase();
            
            //if user enters "E" or "e" exit program
            if (input.equals("E"))
                break;

            if (input.equals("U") || input.equals("D") || input.equals("L") || input.equals("R")) {
                while (true) {
                    System.out.print("Enter a magnitude (integer): ");
                    if (scanner.hasNextInt()) {
                        magnitude = scanner.nextInt();
                        scanner.nextLine(); // Consume newline character
                        break; // Exit loop if integer input is successful
                    } else {
                    System.out.println("Invalid input. Please enter an integer.");
                    scanner.nextLine(); // Consume invalid input
                    }
                }
                
                vector = new Vector(input, magnitude); //input and magnitude varibles into Vector contructor
                box = grid.GetBox();
                box.Push(vector); //push box in direction of user's input
                
                //draw the box again showing the box moving
                grid.Draw();
            }
            else{ //if user input (U,D,L,R,E) invalid - error message
                System.out.println("Invalid input. Please enter valid letter.");
            }
        }                                
    }
}
