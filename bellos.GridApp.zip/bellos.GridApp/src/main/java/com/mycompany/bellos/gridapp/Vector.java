/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bellos.gridapp;

/**
 *
 * @author Elieya
 */
public class Vector {
    private final String direction;
    private final int magnitude;

    public Vector(String direction, int magnitude) {
        this.direction = direction;
        this.magnitude = magnitude;
    }

    public String GetDirection() {
        return direction;
    }

    public int GetMagnitude() {
        return magnitude;
    }
}
